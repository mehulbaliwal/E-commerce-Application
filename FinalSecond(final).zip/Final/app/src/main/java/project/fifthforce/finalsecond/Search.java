package project.fifthforce.finalsecond;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;


import java.util.ArrayList;

public class Search extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        SearchView searchView=(SearchView)findViewById(R.id.searchView);
        ListView listView=(ListView)findViewById(R.id.listView);

        ArrayList<String> list=new ArrayList<String>();

        list.add("Vegetables");
        list.add("Cereals");
        list.add("Pulses");

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,list);

        listView.setAdapter(adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent= new Intent();
                intent.setClass(getApplicationContext(),activity_searched_item.class);
                String str_pos = String.valueOf(position);
                intent.putExtra("pos",str_pos);//0 for veg, 1 for cereals 2 for pulses
                startActivity(intent);
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);//back button but not working only showing

    }
}