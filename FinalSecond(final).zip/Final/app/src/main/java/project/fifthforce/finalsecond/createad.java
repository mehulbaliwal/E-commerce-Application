package project.fifthforce.finalsecond;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class createad extends AppCompatActivity {
    DBHelper gm;
    AutoCompleteTextView amt,prc;
    String s1,s2,s3,s4;
    Spinner spin1,spin2;
    Button btn;
    ArrayList<String> arrayList_parent;
    ArrayAdapter<String> arrayAdapter_parent;
    ArrayList<String>arrayList_VEGETABLES,arrayList_CEREALS,arrayList_PULSES;
    ArrayAdapter<String>arrayAdapter_child;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createad);
        amt=(AutoCompleteTextView)findViewById(R.id.amt);
        prc=(AutoCompleteTextView)findViewById(R.id.prc);
        btn=(Button)findViewById(R.id.btn);
        gm = new DBHelper(this);

        spin1=(Spinner)findViewById(R.id.spin1);
        spin2=(Spinner)findViewById(R.id.spin2);

        arrayList_parent=new ArrayList<>();
        arrayList_parent.add("VEGETABLES");
        arrayList_parent.add("CEREALS");
        arrayList_parent.add("PULSES");

        arrayAdapter_parent= new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item,arrayList_parent);
        spin1.setAdapter(arrayAdapter_parent);


        arrayList_VEGETABLES=new ArrayList<>();
        arrayList_VEGETABLES.add("ONIONS");
        arrayList_VEGETABLES.add("POTATOES");
        arrayList_VEGETABLES.add("TOMATOES");

        arrayList_CEREALS=new ArrayList<>();
        arrayList_CEREALS.add("WHEAT");
        arrayList_CEREALS.add("RICE");
        arrayList_CEREALS.add("MAIZE");

        arrayList_PULSES=new ArrayList<>();
        arrayList_PULSES.add("KIDNEY BEANS");
        arrayList_PULSES.add("CHICK PEAS");
        arrayList_PULSES.add("LENTILS");

        spin1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==0)
                {
                    arrayAdapter_child=new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item,arrayList_VEGETABLES);
                    s1="VEGETABLES";
                }
                if(position==1)
                {
                    arrayAdapter_child=new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item,arrayList_CEREALS);
                    s1="CEREALS";
                }
                if(position==2)
                {
                    arrayAdapter_child=new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_item,arrayList_PULSES);
                    s1="PULSES";
                }
                spin2.setAdapter(arrayAdapter_child);
                spin2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        if(position==0)
                        {
                            if(s1=="VEGETABLES")
                            {
                                s2="ONIONS";
                            }
                            else if(s1=="CEREALS")
                            {
                                s2="WHEAT";
                            }else
                            {
                                s2="KIDNEY BEANS";
                            }
                        }
                        if(position==1)
                        {
                            if(s1=="VEGETABLES")
                            {
                                s2="POTATOES";
                            }
                            else if(s1=="CEREALS")
                            {
                                s2="RICE";
                            }else
                            {
                                s2="CHICK BEANS";
                            }
                        }
                        if(position==2)
                        {
                            if(s1=="VEGETABLES")
                            {
                                s2="TOMATOES";
                            }
                            else if(s1=="CEREALS")
                            {
                                s2="MAIZE";
                            }else
                            {
                                s2="LENTILS";
                            }
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s3=amt.getText().toString();
                s4=prc.getText().toString();
                String phn=getIntent().getStringExtra("user");
                boolean b1=gm.insertadData(s1,s2,s3,s4);
                if(b1==true){
                    Toast.makeText( getApplicationContext(), "SUCCESSFULLY INSERTED", Toast.LENGTH_SHORT).show();

                }else {
                    Toast.makeText( getApplicationContext(), "FAILED TO INSERT", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}