package project.fifthforce.finalsecond;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    public static final String DBNAME = "users";

    public DBHelper(Context context) {
        super(context, "users.db", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase MyDB) {
        Log.d("dblogin","done 1");
        MyDB.execSQL("CREATE TABLE login ( id INTEGER PRIMARY KEY,phone_number TEXT ,password TEXT, type TEXT )");
        Log.d("dblogin","done 2");
        MyDB.execSQL("CREATE TABLE ad ( id INTEGER PRIMARY KEY,type1 TEXT ,type2 TEXT, quantity TEXT, price TEXT,loginid INTEGER )");
        Log.d("dblogin","done 3");
        MyDB.execSQL("CREATE TABLE info ( id INTEGER PRIMARY KEY,name TEXT ,address TEXT )");
        Log.d("dblogin","done 4");
    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists login");
        Log.d("dblogin","done 3");


    }
    public boolean insertData(String phone_number, String password){
        String type=params.KEY_TYPE1;
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put(params.KEY_PHONE, phone_number);
        contentValues.put(params.KEY_PASS, password);
        contentValues.put(params.KEY_TYPE, type);
        long result =MyDB.insert("login", null , contentValues);
        return result != -1;

    }
    public Boolean checkusername(String username){
        SQLiteDatabase MyDB = this.getReadableDatabase();
        Cursor cursor = MyDB.rawQuery("select * from login where phone_number = ? and type=? ", new String[] {username,params.KEY_TYPE1});
        return cursor.getCount() > 0;
    }
    public Boolean checkusernamepassword(String username, String password){
        SQLiteDatabase MyDB = this.getReadableDatabase();
        Cursor cursor = MyDB.rawQuery("select * from login where phone_number = ? and password = ? and type=?", new String[] {username,password,params.KEY_TYPE1});
        return cursor.getCount() > 0;
    }
    public List<logindb> getAllContacts(){
        List<logindb> loginList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        // Generate the query to read from the database
        String select = "SELECT * FROM " + params.TABLE_NAME;
        Cursor cursor = db.rawQuery(select, null);

        //Loop through now
        if(cursor.moveToFirst()){
            do{
                logindb login = new logindb();
                login.setId(Integer.parseInt(cursor.getString(0)));
                login.setPhone_number(cursor.getString(1));
                login.setPassword(cursor.getString(2));
                login.setType(cursor.getString(3));
                loginList.add(login);
            }while(cursor.moveToNext());
        }
        return loginList;
    }
    public boolean insertadData(String type1, String type2, String quantity, String price){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put("type1", type1);
        contentValues.put("type2", type2);
        contentValues.put("quantity", quantity);
        contentValues.put("price", price);
        contentValues.put("loginid", params.LOGIN_ID);
        Log.d("dblogin","insert ad data 1");
        long result =MyDB.insert("ad", null , contentValues);
        Log.d("dblogin","insert ad data 2");
        return result != -1;

    }

    public List<logindb> login_id(){
        List<logindb> loginList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        // Generate the query to read from the database
        Cursor cursor = db.rawQuery("SELECT * FROM login WHERE phone_number = ?and type=?",new String[]{params.LOGIN_USER,params.KEY_TYPE1});
        //Loop through now
        if(cursor.moveToFirst()){
            logindb login = new logindb();
            login.setId(Integer.parseInt(cursor.getString(0)));
            loginList.add(login);
        }
        return loginList;
    }
    public Cursor getdata(String username){
        Log.d("dblogin",""+params.LOGIN_ID);
        SQLiteDatabase MyDB = this.getWritableDatabase();
        return MyDB.rawQuery("select * from ad where loginid = ?", new String[] {Integer.toString(params.LOGIN_ID)});

    }
    public boolean deletedata(String id) {
        SQLiteDatabase MyDB = this.getWritableDatabase();
        long r =     MyDB.delete("ad","id = ?",new String[] {id});
        return r!=-1;
    }
    //information
    public boolean insertData1(String name, String address){
        String type=params.KEY_TYPE1;
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();
        contentValues.put(params.KEY_PHONE, phone_number);
        contentValues.put(params.KEY_PASS, password);
        contentValues.put(params.KEY_TYPE, type);
        long result =MyDB.insert("login", null , contentValues);
        return result != -1;

    }

}


