package project.fifthforce.finalsecond;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class Register extends AppCompatActivity {
    String name = null;
    EditText phone, password, retypepassword;
    Button signup, login;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Toast.makeText(getApplicationContext(), params.KEY_TYPE1, Toast.LENGTH_SHORT).show();





        phone = (EditText) findViewById(R.id.phone);
        password = (EditText) findViewById(R.id.password);
        retypepassword = (EditText) findViewById(R.id.retypepassword);
        signup = (Button) findViewById(R.id.btnsignup);
        login = (Button) findViewById(R.id.btnExistinglogin);

        DB = new DBHelper(this);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = phone.getText().toString();
                String pass = password.getText().toString();
                String retypepass = retypepassword.getText().toString();



                if (user.equals("") || pass.equals("") || retypepass.equals("")){
                    Toast.makeText(getApplicationContext(), "please fill all the fields", Toast.LENGTH_SHORT).show();

                }
                else {
                    if (pass.equals(retypepass)) {
                        boolean checkuser = DB.checkusername(user);
                        if (!checkuser) {
                            boolean insert = DB.insertData(user, pass);
                            if (insert) {
                                Toast.makeText(getApplicationContext(), "Registered successfully", Toast.LENGTH_SHORT).show();
                                if (params.KEY_TYPE1.equals("BUY")) {
                                    Intent intent = new Intent(getApplicationContext(), buydashboard.class);
                                    Toast.makeText(getApplicationContext(), " Buyer Dashboard", Toast.LENGTH_SHORT).show();
                                    startActivity(intent);
                                } else if (params.KEY_TYPE1.equals("SELL")) {
                                    params.LOGIN_USER=user;
                                    Intent intent = new Intent(getApplicationContext(), selldashboard.class);
                                    Toast.makeText(getApplicationContext(), " Seller Dashboard", Toast.LENGTH_SHORT).show();
                                    startActivity(intent);
                                }


                            } else {
                                Toast.makeText(getApplicationContext(), "Registration failed", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "User already exists, please login", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Passwords are not matching", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getApplicationContext(), login.class);
                Toast.makeText(getApplicationContext(),"Please Login",Toast.LENGTH_SHORT).show();
                intent.putExtra("Name",name);
                startActivity(intent);
            }
        });
        // Get all contacts
        List<logindb> allContacts = DB.getAllContacts();
        for (logindb contact : allContacts) {
            Log.d("dblogin", "\nId: " + contact.getId() + "\n" +
                    "Phone Number: " + contact.getPhone_number() + "\n" +
                    "Password: " + contact.getPassword() + "\n" +
                    "Type: " + contact.getType() + "\n");
        }
// Get all contacts


    }

}
