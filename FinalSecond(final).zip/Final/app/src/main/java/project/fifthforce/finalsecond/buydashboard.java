package project.fifthforce.finalsecond;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class buydashboard extends AppCompatActivity {

    ImageButton accessprofile1, home1, search1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buydashboard);

        accessprofile1 = (ImageButton) findViewById(R.id.accessprofile1);
        accessprofile1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(buydashboard.this, "My Profile", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), buyerProfile.class);
                startActivity(intent);
            }
        });
        search1=(ImageButton) findViewById(R.id.search1);
        search1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Search.class);
                startActivity(intent);
            }
        });
        home1=(ImageButton)findViewById(R.id.home1);
        home1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), home.class);
                startActivity(intent);
            }
        });
    }
}