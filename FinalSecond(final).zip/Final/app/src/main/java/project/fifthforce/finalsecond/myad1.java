package project.fifthforce.finalsecond;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;
import android.widget.TextView;

public class myad1 extends AppCompatActivity {
    DBHelper gm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myad1);
        LinearLayout ly=(LinearLayout)findViewById(R.id.ly);
        gm=new DBHelper(this);
        String user=getIntent().getStringExtra("user");
        Cursor b2=gm.getdata(user);
        Log.d("dblogin",""+params.LOGIN_ID);
        int n=b2.getCount();
        String[] s1=new String[n];
        String[] s2=new String[n];
        String[] s3=new String[n];
        String[] s4=new String[n];
        int k=0;
        while(b2.moveToNext()){
            s1[k]=b2.getString(1);
            s2[k]=b2.getString(2);
            s3[k]=b2.getString(3);
            s4[k]=b2.getString(4);
            k++;
        }
        LinearLayout[] cd=new LinearLayout[n];
        TextView[] t1=new TextView[n];
        TextView[] t2=new TextView[n];
        TextView[] t3=new TextView[n];
        TextView[] t4=new TextView[n];
        int j;
        for (int i=0;i<n;i++)
        {
            j=i;
            cd[j]=new LinearLayout(myad1.this);
            cd[j].setOrientation(LinearLayout.VERTICAL);
            cd[j].setBackgroundResource(R.drawable.ic_launcher_background);
            cd[j].setPadding(100,50,50,50);
            cd[j].setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,500
            ));
            t1[j]=new TextView(myad1.this);
            t1[j].setText("CATEGORY : "+s1[j]);
            t1[j].setHeight(100);
            t1[j].setTextSize(20);
            cd[j].addView(t1[j]);
            t2[j]=new TextView(myad1.this);
            t2[j].setText("ITEM : "+s2[j]);
            t2[j].setHeight(100);
            t2[j].setTextSize(20);
            cd[j].addView(t2[j]);
            t3[j]=new TextView(myad1.this);
            t3[j].setText(s3[j]+"KG");
            t3[j].setHeight(100);
            t3[j].setTextSize(20);
            cd[j].addView(t3[j]);
            t4[j]=new TextView(myad1.this);
            t4[j].setText(s4[j]);
            t4[j].setHeight(200);
            t4[j].setTextSize(20);
            cd[j].addView(t4[j]);
            ly.addView(cd[j]);
            LinearLayout sp=new LinearLayout(myad1.this);
            sp.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,100
            ));
            ly.addView(sp);
        }
    }
}